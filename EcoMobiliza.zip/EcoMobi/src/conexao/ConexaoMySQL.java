package conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexaoMySQL {

    public static Connection conectar() {
        Connection conexao = null;
        try {
            String url = "jdbc:mysql://localhost:3306/eco_mobiliza";
            String usuario = "root";
            String senha = ""; 

            conexao = DriverManager.getConnection(url, usuario, senha);
            System.out.println("✅ Conectado com sucesso!");
        } catch (SQLException e) {
            System.out.println("❌ Erro na conexão: " + e.getMessage());
        }

        return conexao;
    }

    public static void main(String[] args) {
        conectar(); // Testar conexão
    }
}

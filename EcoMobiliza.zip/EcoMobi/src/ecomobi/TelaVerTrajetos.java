/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package ecomobi;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class TelaVerTrajetos extends javax.swing.JFrame {
    
    
    public TelaVerTrajetos() {
        initComponents();
         carregarTrajetos();
    }
private void carregarTrajetos() {
    DefaultTableModel modelo = (DefaultTableModel) tabelaTrajetos.getModel();
    modelo.setRowCount(0); // Limpa a tabela antes de preencher

    try (var conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/eco_mobiliza", "root", "")) {
        String sql = "SELECT m.nome AS transporte, t.distancia_km, t.data, (t.distancia_km * m.fator_emissao) AS co2 " +
                     "FROM trajeto t JOIN meio_transporte m ON t.id_transporte = m.id WHERE t.id_usuario = 1";
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(sql);

        while (rs.next()) {
            String transporte = rs.getString("transporte");
            double distancia = rs.getDouble("distancia_km");
            String data = rs.getString("data");
            double co2 = rs.getDouble("co2");

            modelo.addRow(new Object[]{transporte, distancia, data, co2});
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Erro ao carregar trajetos: " + e.getMessage());
    }
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabelaTrajetos = new javax.swing.JTable();
        botaoSair = new javax.swing.JButton();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Transporte", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(240, 253, 241));

        jPanel1.setBackground(new java.awt.Color(240, 253, 241));

        tabelaTrajetos.setBackground(new java.awt.Color(240, 253, 241));
        tabelaTrajetos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"  Bicicleta", "5.0", "2025-06-10", "0.00"},
                {"  Onibus", "12.5", "2025-06-12", "1.00"},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Transporte", "Distância (km)", "Data", "CO₂ (kg)"
            }
        ));
        tabelaTrajetos.setGridColor(new java.awt.Color(240, 253, 241));
        tabelaTrajetos.setInheritsPopupMenu(true);
        tabelaTrajetos.setRowSelectionAllowed(false);
        tabelaTrajetos.setSelectionBackground(new java.awt.Color(240, 253, 241));
        tabelaTrajetos.setSelectionForeground(new java.awt.Color(240, 253, 241));
        tabelaTrajetos.setShowGrid(false);
        jScrollPane2.setViewportView(tabelaTrajetos);

        botaoSair.setBackground(new java.awt.Color(0, 100, 0));
        botaoSair.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        botaoSair.setForeground(java.awt.Color.white);
        botaoSair.setLabel("Sair");
        botaoSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botaoSairActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(147, 147, 147)
                .addComponent(botaoSair, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(30, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(botaoSair, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botaoSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botaoSairActionPerformed
  new TelaPrincipal().setVisible(true);
        dispose(); 
    }//GEN-LAST:event_botaoSairActionPerformed

    /**
     * @param args the command line arguments
     */

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botaoSair;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable tabelaTrajetos;
    // End of variables declaration//GEN-END:variables
}
